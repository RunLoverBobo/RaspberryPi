#!/bin/sh

set -x
sudo java -cp ./libs/*:./bin/marsiot-pi-sdk.jar com.example.Main  
